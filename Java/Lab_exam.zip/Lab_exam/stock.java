import java.util.*;

class User {
    protected int userID;
    protected String name;
    protected String dateOfBirth;
    protected String address;
    protected String pan;
    public static ArrayList<Item> itlist = new ArrayList<Item>();
    public static ArrayList<FoodItem> foodList = new ArrayList<FoodItem>();
    public static ArrayList<NonFoodItem> NonFoodList = new ArrayList<NonFoodItem>();
    public static ArrayList<Sell> sellList = new ArrayList<Sell>();
    public static ArrayList<Return> returnList = new ArrayList<Return>();

    User() {

    }

    User(int uid, String nm, String dob, String add, String pn) {
        this.userID = uid;
        this.name = nm;
        this.dateOfBirth = dob;
        this.address = add;
        this.pan = pn;
    }
}

class Admin extends User {
    protected String dateOfJoining;
    protected int salary;
    protected int permissableOperateions;

    Admin() {

    }

    Admin(int uid, String nm, String dob, String add, String pn, String jdate, int sal, int op) {
        super(uid, nm, dob, add, pn);
        this.dateOfJoining = jdate;
        this.salary = sal;
        this.permissableOperateions = op;
    }

    public void addNewStock(Item it) {
        itlist.add(it);
    }

    public void deleteStock(int itcode) {
        int i = 0;
        for (Item item : itlist) {
            if (itcode == item.itemCode) {
                if (item.availabeQty == 0) {
                    System.out.println("Item unavailable");
                } else {
                    itlist.remove(i);
                    break;
                }
            }
            i++;
        }
    }

    public void modifyStock(int itcode) {
        Scanner sc = new Scanner(System.in);
        for (Item item : itlist) {
            if (itcode == item.itemCode) {
                System.out.println("Enter the new price: ");
                int pr = sc.nextInt();
                item.price = pr;
                System.out.println("Enter the new quantity: ");
                int qu = sc.nextInt();
                item.quantity = qu;
            }
        }
    }

}

class General extends User {
    protected String dateOfJoining;
    protected int salary;
    protected int dutyHourPerDay;

    General() {

    }

    General(int uid, String nm, String dob, String add, String pn, String jdate, int sal, int hours) {
        super(uid, nm, dob, add, pn);
        this.dateOfJoining = jdate;
        this.salary = sal;
        this.dutyHourPerDay = hours;
    }

    public void sellItem(int itcode, int qu) {
        Scanner sc = new Scanner(Syste.in);
        for (Item item : itlist) {
            it(itcode == item.itemCode) {
                System.out.println("Enter date of sell: ");
                String dt = sc.nextLine();
                int price = item.price;
                int avail = item.avail;
                int amount = qu * price;
                if(avail != 0)
                {
                    Sell newsell = new Sell(itcode, price, avail, dt, qu, amount);
                    sellList.add(newsell);
                }
                
                
            }
        }
    }

    public void returnItem(int itcode, int qu) {
        for (Item item : foodList) {
            it(itcode == item.itemCode) {
                System.out.println("Food Item can't be returned");
                return;
            }
        }
        for (Item item : itlist) {
            it(itcode == item.itemCode) {
                System.out.println("Enter date of return: ");
                String dt = sc.nextLine();
                int price = item.price;
                int avail = item.avail;
                int amount = qu * price;
                
                Return newreturn = new Return(itcode, price, avail, dt, qu, amount);
                returnList.add(newreturn);

            }
        }
    }

    public void displaystock(int itcode) {
        for (Item item : itlist) {
            if (itcode == item.itemCode) {
                System.out.println("Item code: " + itcode);
                System.out.println("Item price: " + item.price);
                System.out.println("Item quantity: " + item.availabeQty);
            }
        }
    }

    public int yearOf(String date) {
        String ey = date.substring(4, 6);
        int eyi = Integer.parseInt(ey);
        return eyi;
    }

    public void displaysell(String startDate, String endDate) {
        String sy = startDate.substring(4, 6);
        String ey = endDate.substring(4, 6);

        int syi = Integer.parseInt(sy);
        int eyi = Integer.parseInt(ey);

        for (Sell sitem : sellList) {
            if ((yearOf(sitem.dateOfSell) >= syi) && (yearOf(sitem.dateOfSell)) <= eyi) {
                System.out.println("Item code=" + sitem.itemCode);
                System.out.println(("Item available=" + sitem.availabeQty));
                System.out.println("Item Price=" + sitem.price);
                System.out.println("Item quantity=" + sitem.quantity);
            }
        }
    }
}

class Item {
    int itemCode;
    int price;
    int availabeQty;

    Item() {

    }

    Item(int code, int pr, int avail) {
        this.itemCode = code;
        this.price = pr;
        this.availabeQty = avail;
    }
}

class FoodItem extends Item {
    String dateOfExpiry;

    FoodItem() {

    }

    FoodItem(int code, int pr, int avail, String exp) {
        super(code, pr, avail);
        this.dateOfExpiry = exp;
    }

}

class NonFoodItem extends Item {
    int returnCount;

    NonFoodItem() {

    }

    NonFoodItem(int code, int pr, int avail, int rcount) {
        super(code, pr, avail);
        this.returnCount = rcount;
    }
}

class Sell {
    String dateOfSell;
    int quantity;
    int totalAmount;

    Sell() {

    }

    Sell(String dsell, int qu, int tamount) {
        this.dateOfSell = dsell;
        this.quantity = qu;
        this.totalAmount = tamount;
    }
}

class Return {
    String dateOfReturn;
    int quantity;
    int returnAmount;

    Return() {

    }

    Return(String dreturn, int qu, int ramount) {
        this.dateOfReturn = dreturn;
        this.quantity = qu;
        this.returnAmount = ramount;
    }
}

public class stock {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Admin ad = new Admin(12, "manojit", "101011987", "Sector 2, Guwahati", "EYC2341", "12092007", 100000, 6);
        General gk = new General(14, "manjit", "12112001", "Bloc A, Shillong", "AX13D", "11102012", 30000, 8);
        System.out.println("Enter 1 for admin and 2 for General. ");
        System.out.print("Enter Choice: ");
        int ch = sc.nextInt();
        if (ch == 1) {
            System.out.println("Enter 1 to add stock.\nEnter 2 to delete stock.\nEnter 3 to modify stock.");
            System.out.print("Enter Choice: ");
            int c = sc.nextInt();
            switch (c) {
                case 1:
                    System.out.println("Enter item code: ");
                    int code = sc.nextInt();
                    System.out.println("Enter price: ");
                    int price = sc.nextInt();
                    System.out.println("Enter Available quantity: ");
                    int qu = sc.nextInt();
                    System.out.println("Enter 1 for fooditem and 2 for non-food item: ");
                    int ce = sc.nextInt();
                    if(ce==1) {
                        sc.nextLine();
                        System.out.println("Enter expiry date: ");
                        String dt = sc.nextLine();
                        FoodItem fd = new FoodItem(code, price, qu, dt);
                        ad.addNewStock(fd);
                    }
                    else {
                        System.out.println("Enter return count: ");
                        int rc = sc.nextInt();
                        NonFoodItem nf = new NonFoodItem(code, price, qu, dt);
                        ad.addNewStock(nf);
                    }
                    break;
            
                default:
                    break;
            }
        }
    }
}
