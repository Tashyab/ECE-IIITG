fs = 8;
ts = 1/fs;
k = 0:fs-1;

x = 5 + 2*cos(2*pi*ts*k-pi/2) + 3*cos(4*pi*ts*k);
disp(x);

y = zeros(fs);
for a = 1:fs
    for b = 1:fs
         y(a, b) = exp((-1i*2*pi*(a-1)*(b-1))/fs);
    end
end

disp(y);

z = y*transpose(x);
disp(z);
disp(abs(z));
stem(k, abs(z));