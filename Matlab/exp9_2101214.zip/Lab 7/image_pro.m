clear 
clc
i = imread('sar.gif');
phase_only(i);


