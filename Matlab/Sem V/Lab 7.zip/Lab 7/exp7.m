clc 
clear

N = 10000;
Ts = 0.01;
fc = 1/Ts;
t = 0:1/fc:1;
Es = 1;
A = sqrt(2*Es/Ts);
seq = zeros(1, N);

for i = 1:N
    if(rand(1)>0.5)
        seq(i) = 1;
    else
        seq(i) = 0;
    end
end

seq0 = -A * cos(2*pi*t);
seq1 = A * cos(2*pi*t);

E_db = [-10,-5,0,5,6,8,10];
E_sigma = power(10, E_db/10);
sigma = 1./E_sigma;

err_calc = zeros(1, length(E_db));
err_inbuilt = zeros(1, length(E_db));

r = zeros(1, N);
for j = 1:length(E_db)
    for i=1:N
        if seq(i) == 0
            r(i) = -1 + randn(1)*sqrt(sigma(j));
        else
            r(i) = 1 + randn(1)*sqrt(sigma(j));
        end
    end
    new_seq=r>=0;
    err=new_seq~=seq;
    err_calc(j)=sum(err)/N;
    err_inbuilt(j) = qfunc(sqrt(Es/sigma(j)));
end

semilogy(E_db, err_inbuilt, 'Marker', 'o', 'MarkerSize', 10);
hold on
semilogy(E_db, err_calc, 'Marker','square', 'MarkerSize', 2);
title("Actual vs Calculated error over different SNR(db)")

    